# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

##-------------------##-------------------##-------------------
##-------------------##-------------------##-------------------
### function
##-------------------##-------------------##-------------------

PLM.fun=function(n,P,non..function,sigma.error,true.beta =1,
                 max.iter=250, plotting=FALSE,
                 kernel.fun="biweight", Estimation..method = "speckman")
{
  ##-----------------------------
  b <- rep(true.beta,P)

  x  <- matrix(NA,n,P); for(i in 1:P) x[,i]=runif(n,0,1)

  t  <- runif(n,-1,1)

  if (non..function == "f1") non.fun <- function(t){ 1.5*sin(pi*t) }
  if (non..function == "f2") non.fun <- function(t){ 1.5*sin(pi*t^2) }
  if (non..function == "f3") non.fun <- function(t){ 3*sin(pi*t^3) }
  if (non..function == "f4") non.fun <- function(t){ t+t^2 +t^4 }
  z=non.fun(t)
  y  <- x %*% b + z + rnorm(n,0,sigma.error)

  ## fit partial linear model (PLM)
  #1- kgplm depend kernel (speckman or backfitiing)
  smooth_kernel=bandwidth.scott(t,kernel=kernel.fun)
  k.plm <- kgplm(x,t,y,h=smooth_kernel,
                 method=Estimation..method,family="gaussian",link="identity",
                 max.iter = max.iter)

  ##2- sgplm1 depend spline(speckman or backfitiing).
  smooth_spline=smooth.spline(t,y, control.spar = list(tol = 1e-4,maxit=500))
  spar=smooth_spline$spar

  s.plm <- sgplm1(x,t,y,spar=spar,method=Estimation..method,
                  family="gaussian",link="identity",
                  max.iter = max.iter,
                  control.spar = list(tol = 1e-4,maxit=500))
  ##############################################################
  ##3- speckman depend b-spline(new estimator in this paper).
  library("splines")
  df = 5
  bs.v= bs(z,df=df)

  raw..data=cbind.data.frame(y,x)
  ez.matrix=matrix(NA, n,P+1)

  for(i in 1:(P+1)){
    ez.matrix[,i] <- predict (lm(raw..data[,i] ~ bs.v))
  }

  new..data=raw..data-ez.matrix

  ## linear regression
  par.component <- lm(y~ .-1, data=new..data )
  beta <- cbind(par.component$coefficients)

  yxb <- y - x%*%beta

  ## Storage matricies

  mz <- predict (lm(yxb ~  bs.v))


  ########################################################################


  ##---- MSE values ---------------

  ## MSE.parametric
  beta.hat.kernel=k.plm$b
  beta.hat.splin=s.plm$b
  beta.hat.B_splin=beta

  bias.matrix=cbind(beta.hat.kernel,beta.hat.splin,beta.hat.B_splin)-b
  MSE.parametric=apply(bias.matrix^2,2,sum)/P

  ## MSE.non_parametric
  o <- order(t)

  bias.np.k = k.plm$m[o]-non.fun(t[o])
  bias.np.s = s.plm$m[o]-non.fun(t[o])
  bias.np.Bs = mz[o]-non.fun(t[o])

  MSE.k= sum(bias.np.k^2)/n
  MSE.s= sum(bias.np.s^2)/n
  MSE.Bs= sum(bias.np.Bs^2)/n


  MSE.non_parametric=c(MSE.k,MSE.s,MSE.Bs)

  ##------------------------------
  MSE.values=cbind.data.frame(MSE.par=MSE.parametric,
                              MSE.non_par=MSE.non_parametric)

  row.names(MSE.values) = c("kernel","Spline","B-Spline")


  if (plotting==TRUE){
    ##-------------------
    ### plotting
    ##-------------------
    linetype=c(1,4,5,6)
    o <- order(t)
    ylim <- range(c(non.fun(t[o]),k.plm$m,mz),na.rm=TRUE)
    plot(t[o],non.fun(t[o]),type="l" ,ylab = "", xlab = "z",ylim=1.5*ylim,
         lty=1,lwd=2.5)
    lines(t[o],k.plm$m[o], col="blue", lty=4,lwd=2)
    lines(t[o],s.plm$m[o], col="red", lty=5,lwd=2)
    lines(t[o],mz[o], col="green", lty=6,lwd=2)

    #rug(t);
    title(non..function)

    legend("top",horiz = T, lty=linetype, lwd=2,
           legend = c("True carve","Kernel", "Spline","B-Spline"), col = c("black", "blue","red","green"))
  }
  return(MSE.values)

}

